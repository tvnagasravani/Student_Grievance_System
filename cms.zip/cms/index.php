<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Complaint Management System</title>
  <link rel="stylesheet" href="index.css">
  
</head>

<body>
  <div class="header_section">
    <div class="logo">
      <h1>CMS</h1>
    </div>
    <nav>
      <ul class="navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="admin/index.php">Admin</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="user/index.php">User Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="user/registration.php">User Registration</a>
        </li>
      </ul>
    </nav>
  </div>

  <div class="container">
    <main class="content">
      <section class="about-us">
        <h1>Welcome to Unity University!</h1>
        <p>
          Unity University is a leading institution dedicated to providing a transformative educational experience. We offer a wide range of programs, fostering academic excellence, critical thinking, and social responsibility in our students.
        </p>
        <img src="college.jpg" alt="Unity University Campus" class="about-image">
        <h2>Our Features</h2>
        <div class="features-container">
          <div class="feature">
            <i class="fas fa-graduation-cap"></i>
            <h3>Outstanding Academics</h3>
            <p>Our diverse range of programs are taught by renowned faculty, ensuring a high-quality education.</p>
          </div>
          <div class="feature">
            <i class="fas fa-users"></i>
            <h3>Diverse Community</h3>
            <p>We celebrate diversity and create a welcoming environment for students from all backgrounds.</p>
          </div>
          <div class="feature">
            <i class="fas fa-flask"></i>
            <h3>Research Opportunities</h3>
            <p>Students can participate in cutting-edge research alongside our accomplished faculty.</p>
          </div>
          <div class="feature">
            <i class="fas fa-building"></i>
            <h3>Modern Facilities</h3>
            <p>We offer state-of-the-art facilities to support learning and student life.</p>
          </div>
        </div>
      </section>
    </main>
  </div>

  
</body>

</html>
