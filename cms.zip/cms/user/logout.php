<?php
session_start();
include("include/config.php");

// Check if the session 'login' is set
if(isset($_SESSION['login']) && !empty($_SESSION['login'])) {
    $username = $_SESSION['login'];

    // Set the timezone and get the current date and time
    date_default_timezone_set('Asia/Kolkata');
    $ldate = date('d-m-Y h:i:s A', time());

    // Prepare the SQL query to prevent SQL injection
    $stmt = $con->prepare("UPDATE userlog SET logout = ? WHERE username = ? ORDER BY id DESC LIMIT 1");
    $stmt->bind_param("ss", $ldate, $username);

    // Execute the query and check for errors
    if($stmt->execute()) {
        $stmt->close();
    } else {
        // Log or handle the error if the query fails
        error_log("Error updating user log: " . $stmt->error);
    }
}

// Unset all session variables
session_unset();
session_destroy(); // It is a good practice to also destroy the session

// Redirect to the index page
?>
<script language="javascript">
document.location="index.php";
</script>
