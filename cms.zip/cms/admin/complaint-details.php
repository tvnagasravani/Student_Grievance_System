<?php
session_start();
include('include/config.php');
if(strlen($_SESSION['aid'])==0)
{   
    header('location:index.php');
}
else{
    date_default_timezone_set('Asia/Kolkata');// change according timezone
    $currentTime = date( 'd-m-Y h:i:s A', time () );

    if(isset($_POST['updateStatus'])){
        $cid = $_POST['cid'];
        $status = $_POST['status'];
        $query = mysqli_query($con, "UPDATE tblcomplaints SET status='$status' WHERE complaintNumber='$cid'");
        if($query){
            echo "<script>alert('Status updated successfully');</script>";
        } else {
            echo "<script>alert('Status update failed');</script>";
        }
    }

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>CMS || Complaints Details</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
        }
        .sidebar {
            width: 200px;
            background: skyblue;
            padding: 20px;
            color: skyblue;
            position: fixed;
            height: 100%;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .sidebar a {
            color:white;
            text-decoration: none;
            display: block;
            margin: 10px 0;
            text-size:15px;
        }
        .sidebar a:hover {
            background: #007bff;
            padding-left: 10px;
        }
        .sidebar h2 {
            margin: 0;
            padding: 20px 0;
            text-align: center;
            background: #007bff;
        }
        .container {
            margin-left: 220px;
            max-width: 1200px;
            padding: 20px;
        }
        .breadcrumb {
            list-style: none;
            display: flex;
        }
        .breadcrumb li {
            margin-right: 10px;
        }
        .breadcrumb li a {
            text-decoration: none;
            color: #007bff;
        }
        .card {
            background: #fff;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .card h5 {
            margin: 0 0 20px;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        .table th, .table td {
            padding: 10px;
            border: 1px solid #ddd;
        }
        .badge {
            display: inline-block;
            padding: 0.25em 0.4em;
            font-size: 75%;
            font-weight: 700;
            line-height: 1;
            text-align: center;
            white-space: nowrap;
            vertical-align: baseline;
            border-radius: 0.25rem;
        }
        .badge-danger {
            background-color: #dc3545;
            color: #fff;
        }
        .badge-warning {
            background-color: #ffc107;
            color: #212529;
        }
        .badge-success {
            background-color: #28a745;
            color: #fff;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group select {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
        }
        .btn-primary {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
        }
    </style>
    <script language="javascript" type="text/javascript">
        var popUpWin=0;
        function popUpWindow(URLStr, left, top, width, height)
        {
            if(popUpWin) {
                if(!popUpWin.closed) popUpWin.close();
            }
            popUpWin = open(URLStr,'popUpWin', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=no,copyhistory=yes,width='+600+',height='+600+',left='+left+', top='+top+',screenX='+left+',screenY='+top+'');
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <h2>CMS</h2>
        <div>
            <!-- Additional Sidebar Links can go here -->
        </div>
        <div>
            <a href="all-complaint.php">All Complaints</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    <div class="container">
        <div class="page-header">
            <div class="page-block">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <div class="page-header-title">
                            <h5 class="m-b-10">Complaints Details</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="dashboard.php"><i class="feather icon-home"></i></a></li>
                            <li class="breadcrumb-item"><a href="all-complaint.php">Complaints Details</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-body">
                        <h5>View Complaints Details</h5>
                        <hr>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <tbody>
                                    <?php 
                                    $cid=$_GET['cid'];
                                    $query=mysqli_query($con,"SELECT tblcomplaints.*, users.fullName as name, category.categoryName as catname FROM tblcomplaints JOIN users ON users.id=tblcomplaints.userId JOIN category ON category.id=tblcomplaints.category WHERE tblcomplaints.complaintNumber='$cid'");
                                    while($row=mysqli_fetch_array($query)) { ?>                                  
                                    <tr>
                                        <td><b>Complaint Number</b></td>
                                        <td><?php echo htmlentities($row['complaintNumber']);?></td>
                                        <td><b>Complainant Name</b></td>
                                        <td><?php echo htmlentities($row['name']);?></td>
                                        <td><b>Reg Date</b></td>
                                        <td><?php echo htmlentities($row['regDate']);?></td>
                                    </tr>
                                    <tr>
                                        <td><b>Category</b></td>
                                        <td><?php echo htmlentities($row['catname']);?></td>
                                        <td><b>SubCategory</b></td>
                                        <td><?php echo htmlentities($row['subcategory']);?></td>
                                        <td><b>Complaint Type</b></td>
                                        <td><?php echo htmlentities($row['complaintType']);?></td>
                                    </tr>
                                    <tr>
                                        <td><b>State</b></td>
                                        <td><?php echo htmlentities($row['state']);?></td>
                                        <td><b>Nature of Complaint</b></td>
                                        <td colspan="3"><?php echo htmlentities($row['noc']);?></td>
                                    </tr>
                                    <tr>
                                        <td><b>Complaint Details</b></td>
                                        <td colspan="5"><?php echo htmlentities($row['complaintDetails']);?></td>
                                    </tr>
                                    <tr>
                                        <td><b>File(if any)</b></td>
                                        <td colspan="5">
                                            <?php $cfile=$row['complaintFile'];
                                            if($cfile=="" || $cfile=="NULL") {
                                                echo "File NA";
                                            } else { ?>
                                            <a href="../users/complaintdocs/<?php echo htmlentities($row['complaintFile']);?>" target="_blank"> View File</a>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><b>Final Status</b></td>
                                        <td colspan="5">
                                            <?php $status=$row['status'];
                                            if($status==''): ?>
                                            <span class="badge badge-danger">Not Processed Yet</span>
                                            <?php elseif($status=='in process'):?>
                                            <span class="badge badge-warning">In Process</span>
                                            <?php elseif($status=='closed'):?>
                                            <span class="badge badge-success">Closed</span>
                                            <?php endif;?>
                                        </td>
                                    </tr>
                                    <hr>
                                    <?php 
                                    $ret=mysqli_query($con,"SELECT complaintremark.remark as remark, complaintremark.status as sstatus, complaintremark.remarkDate as rdate FROM complaintremark JOIN tblcomplaints ON tblcomplaints.complaintNumber=complaintremark.complaintNumber WHERE complaintremark.complaintNumber='$cid'");
                                    $cnt=1;
                                    $count=mysqli_num_rows($ret);
                                    if($count): ?>
                                    <tr>
                                        <th>S.No</th>
                                        <th colspan="3">Remark</th>
                                        <th>Status</th>
                                        <th>Updation Date</th>
                                    </tr>
                                    <?php 
                                    while($rw=mysqli_fetch_array($ret)) { ?>
                                    <tr>
                                        <td><?php echo htmlentities($cnt);?></td>
                                        <td colspan="3"><?php echo htmlentities($rw['remark']); ?></td>
                                        <td><?php echo htmlentities($rw['sstatus']); ?></td>
                                        <td><?php echo htmlentities($rw['rdate']); ?></td>
                                    </tr>
                                    <?php $cnt=$cnt+1; } endif; ?>
                                    <tr>
                                        <td colspan="6">
                                            <?php if($row['status'] != "closed") { ?>
                                            <form method="post" action="">
                                                <input type="hidden" name="cid" value="<?php echo htmlentities($row['complaintNumber']); ?>">
                                                <div class="form-group">
                                                    <select name="status">
                                                        <option value="">Select Status</option>
                                                        <option value="not processed">Not Processed</option>
                                                        <option value="in process">In Process</option>
                                                        <option value="closed">Closed</option>
                                                    </select>
                                                </div>
                                                <button type="submit" name="updateStatus" class="btn-primary">Update Status</button>
                                            </form>
                                            <?php } ?>
                                        </td>
                                    </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="assets/js/vendor-all.min.js"></script>
    <script src="assets/js/plugins/bootstrap.min.js"></script>
    <script src="assets/js/pcoded.min.js"></script>
</body>
</html>
<?php } ?>
