
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `fullname` varchar(259) DEFAULT NULL,
  `mobilenumber` bigint(11) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `fullname`, `mobilenumber`, `email`, `username`, `password`, `creationDate`, `updationDate`) VALUES
(1, 'admin', 6302841982, 'admin@gmail.com', 'admin', 'f925916e2754e5e03f75dd58a5733251', '2023-09-12 05:16:16', '18-10-2016 04:18:16');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `categoryName` varchar(255) DEFAULT NULL,
  `categoryDescription` longtext DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `categoryName`, `categoryDescription`, `creationDate`, `updationDate`) VALUES
(1, 'Academic Issues', '', '2023-08-28 07:10:55', '2024-05-31 04:43:33'),
(2, 'Administrative Issues', '', '2023-08-11 10:54:06', '2024-05-31 04:44:11'),
(3, 'Disciplinary Issues', '', '2023-09-12 06:26:48', '2024-05-31 04:44:53'),
(5, 'Infrasturcture Issues', '', '2023-09-12 06:27:36', '2024-05-31 04:45:17');

-- --------------------------------------------------------

--
-- Table structure for table `complaintremark`
--

CREATE TABLE `complaintremark` (
  `id` int(11) NOT NULL,
  `complaintNumber` int(11) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `remark` mediumtext DEFAULT NULL,
  `remarkDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `complaintremark`
--

INSERT INTO `complaintremark` (`id`, `complaintNumber`, `status`, `remark`, `remarkDate`) VALUES
(1, 3, 'in process', 'your ticket forward to associated team', '2023-09-15 13:05:38'),
(2, 3, 'closed', 'Ticket close in favor of user', '2023-09-15 13:06:31'),
(3, 5, 'in process', 'We are reviewing the complaint', '2023-10-01 04:12:48'),
(4, 5, 'closed', 'Issue resolved', '2023-10-01 04:13:12'),
(5, 6, 'closed', 'The issue is resolved', '2024-05-24 06:10:02'),
(6, 7, 'in process', 'We have appointed the teachers accordingly and we would complete as soon as poosible.Rais ethe query if yet not completed', '2024-05-24 10:12:34'),
(7, 8, 'closed', 'Syllabus will be completed and there will be no issue', '2024-05-26 09:54:45'),
(8, 9, 'closed', 'ur request or complaint is closed', '2024-05-26 09:55:36'),
(9, 16, 'closed', 'aa', '2024-05-31 05:37:28');

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `id` int(11) NOT NULL,
  `stateName` varchar(255) DEFAULT NULL,
  `stateDescription` tinytext DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`id`, `stateName`, `stateDescription`, `postingDate`, `updationDate`) VALUES
(3, '1st Year', '', '2023-09-28 16:56:56', '2024-05-24 09:59:41'),
(5, '3rd Year', '', '2023-09-28 16:56:56', '2024-05-24 10:00:45'),
(6, '4th Year', '', '2023-09-28 16:56:56', '2024-05-31 04:58:37'),
(7, '2nd Year', '', '2023-09-28 16:56:56', '2024-05-31 04:58:29');

-- --------------------------------------------------------

--
-- Table structure for table `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `categoryid` int(11) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `subcategory`
--

INSERT INTO `subcategory` (`id`, `categoryid`, `subcategory`, `creationDate`, `updationDate`) VALUES
(1, 1, 'Course Content\r\n', '2023-03-28 07:11:07', '2024-05-31 04:49:19'),
(2, 2, 'Admission Process', '2023-08-28 07:11:20', '2024-05-31 04:51:48'),
(3, 2, 'Fee Payment', '2023-09-14 07:06:44', '2024-05-31 04:52:14'),
(4, 2, 'Hostel Accommodation', '2023-09-12 11:40:13', '2024-05-31 04:52:49'),
(8, 1, 'Examination', '2023-03-28 07:11:07', '2024-05-31 04:49:19'),
(9, 1, 'Results', '2023-08-28 07:11:20', '2024-05-24 09:51:42'),
(10, 1, 'Attendance', '2023-08-28 07:11:20', '2024-05-24 09:51:42'),
(11, 3, 'Ragging', '2023-09-12 11:40:13', '2024-05-31 04:52:49'),
(12, 3, 'Mis Conduct', '2023-09-12 11:40:13', '2024-05-31 04:52:49'),
(13, 3, 'Harrasment', '2023-09-12 11:40:13', '2024-05-31 04:52:49'),
(14, 5, 'Classroom Facilities', '2023-09-12 11:40:13', '2024-05-31 04:57:39'),
(15, 5, 'Lab Equipment', '2023-09-12 11:40:13', '2024-05-31 04:57:44');

-- --------------------------------------------------------

--
-- Table structure for table `tblcomplaints`
--

CREATE TABLE `tblcomplaints` (
  `complaintNumber` int(11) NOT NULL,
  `userId` int(11) DEFAULT NULL,
  `category` int(11) DEFAULT NULL,
  `subcategory` varchar(255) DEFAULT NULL,
  `complaintType` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `noc` varchar(255) DEFAULT NULL,
  `complaintDetails` mediumtext DEFAULT NULL,
  `complaintFile` varchar(255) DEFAULT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `status` varchar(50) DEFAULT NULL,
  `lastUpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcomplaints`
--

INSERT INTO `tblcomplaints` (`complaintNumber`, `userId`, `category`, `subcategory`, `complaintType`, `state`, `noc`, `complaintDetails`, `complaintFile`, `regDate`, `status`, `lastUpdationDate`) VALUES
(2, 4, 1, 'E-wllaet', 'General Query', 'Punjab', 'htrdy', 'dytuj', '7db575b77409a4ad74cb9620814085e8.jpg', '2023-09-15 12:41:41', NULL, NULL),
(3, 1, 1, 'E-wllaet', 'General Query', 'Punjab', 'htrdy', 'dytuj', '7db575b77409a4ad74cb9620814085e8.jpg', '2023-09-15 12:45:26', 'closed', '2023-09-15 13:06:31'),
(4, 5, 1, 'Online Shopping', ' Complaint', 'Delhi', 'Complain against Shopping website', 'This is for testing.', '2c86e2aa7eb4cb4db70379e28fab9b52.pdf', '2023-09-26 01:28:17', NULL, NULL),
(5, 6, 1, 'Online Shopping', 'General Query', 'Punjab', 'Test nature', 'This is for testing', '858828b8b12d041fde07b353a94db5ed.png', '2023-10-01 04:12:07', 'closed', '2023-10-01 04:13:12'),
(6, 7, 2, 'other', 'General Query', 'Uttar Pradesh', 'goods', 'recieved n goods', '122976060da2e9cc8e858688d3851aad.png', '2024-05-24 06:07:54', 'closed', '2024-05-24 06:10:02'),
(7, 7, 1, 'Academics\r\n', 'General Query', '2nd Year', 'The syllabus had not been completed as per scheduled sir', 'I am the student of 3rd year Oof CSE Department . Our syllabus didnot complete as per our schedule . so please focus on this sir.', '41a289620cde66d52ce222041fed4193.png', '2024-05-24 10:09:54', 'in process', '2024-05-24 10:12:34'),
(8, 8, 1, 'Academics\r\n', 'General Query', '1st Year', 'The syllabus had not been completed as per scheduled sir', 'aaaaaa', '836f140260aa77104b569fd7613b7fe0.pdf', '2024-05-26 09:51:33', 'closed', '2024-05-26 09:54:45'),
(9, 9, 1, 'Academics\r\n', 'General Query', '3rd Year', 'The syllabus had not been completed as per scheduled sir', 'the syllabus had not completed as per the scheduled', '836f140260aa77104b569fd7613b7fe0.pdf', '2024-05-26 09:53:32', 'closed', '2024-05-26 09:55:36'),
(18, 11, 1, 'Course Content\r\n', 'General Query', '1st Year', 'aa', 'aaaaaaaaaaaaaaaaa', '1a17060536e593f9056252dc50183195.pdf', '2024-06-06 10:01:55', 'closed', '2024-06-06 10:26:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `userEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `contactNo` bigint(11) DEFAULT NULL,
  `address` tinytext DEFAULT NULL,
  `State` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `pincode` int(6) DEFAULT NULL,
  `userImage` varchar(255) DEFAULT NULL,
  `regDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL,
  `status` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `userEmail`, `password`, `contactNo`, `address`, `State`, `country`, `pincode`, `userImage`, `regDate`, `updationDate`, `status`) VALUES
(2, 'test', 'test@123', '202cb962ac59075b964b07152d234b70', 7894561236, NULL, NULL, NULL, NULL, NULL, '2023-09-13 05:05:11', NULL, 1),

(7, 'T V Naga Sravani', 'tvnagasravani@gmail.com', 'e2fc714c4727ee9395f324cd2e7f331f', 6302841982, NULL, NULL, NULL, NULL, NULL, '2024-05-24 06:05:05', NULL, 1),
(8, 'Thummagunta Venkata Naga Sravani', 'tv@gmail.com', 'e2fc714c4727ee9395f324cd2e7f331f', 6666666666, NULL, NULL, NULL, NULL, NULL, '2024-05-26 09:46:26', NULL, 1),
(9, 'Thummagunta Venkata Naga Sravani', 'tvsv@gmail.com', 'ab56b4d92b40713acc5af89985d4b786', 2222222222, NULL, NULL, NULL, NULL, NULL, '2024-05-26 09:52:35', NULL, 1),
(10, 'T V Naga Sravani', 'tvnag@gmail.com', '4124bc0a9335c27f086f24ba207a4912', 6302841982, NULL, NULL, NULL, NULL, NULL, '2024-05-31 10:29:44', NULL, 1),
(11, 'Thummagunta Venkata Naga Sravani', 'tvsravani02@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', 6666666666, NULL, NULL, NULL, NULL, NULL, '2024-06-06 09:45:44', NULL, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaintremark`
--
ALTER TABLE `complaintremark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcomplaints`
--
ALTER TABLE `tblcomplaints`
  ADD PRIMARY KEY (`complaintNumber`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `complaintremark`
--
ALTER TABLE `complaintremark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `subcategory`
--
ALTER TABLE `subcategory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tblcomplaints`
--
ALTER TABLE `tblcomplaints`
  MODIFY `complaintNumber` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

